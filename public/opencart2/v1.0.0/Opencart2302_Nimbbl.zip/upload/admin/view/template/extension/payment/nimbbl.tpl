<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <div class="page-header">
  <div class="container-fluid">
  <div class="pull-right">
         <button type="submit" form="form-payment" data-toggle="tooltip" title="{{ button_save }}" class="btn btn-primary"><i class="fa fa-save"></i></button>
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a></div>
      <h1><?php echo $heading_title; ?></h1>
 
  <ul class="breadcrumb">
    <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
  </ul>
  </div>
  </div>
  <div class="container-fluid">
    <?php if (isset($error_warning)) { ?>
    <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
  <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i><?php echo $text_edit; ?></h3>
  </div>
  <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" name="form-nimbbl" id="form-nimbbl" class="form-horizontal">
 <div class="box">
  <!--// Nimbbl Start //-->
  <div class="heading">
       <h1><img src="view/image/payment/nimbbllogo.png" alt="nimbbl" /></h1>
   </div>
 <div class="content">
  <div class="panel-body">
        <div class="col-sm-10"> 
			<div class="form-group required">
				<label class="col-sm-20 control-label" for="nimbbl_webhook">Webhook URL: <?php echo $webhook_url; ?></label>
			</div>
			<div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_title"><span data-toggle="tooltip" title="<?php echo $help_title; ?>"><?php echo  $entry_title; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_title" value="<?php echo $nimbbl_title; ?>" placeholder="<?php echo  $entry_title; ?>" id="nimbbl_title" class="form-control" />
              <?php if ($error_title) { ?> 
              <div class="text-danger"><?php echo $error_title; ?></div>
              <?php } ?>
            </div>
			</div>
			
			<div class="form-group required">
				<label class="col-sm-2 control-label" for="nimbbl_mode"><?php echo $entry_mode; ?></label>
				<div class="col-sm-10">
					<select name="nimbbl_mode" id="nimbbl_mode" class="form-control">
						<?php if ($nimbbl_mode == 'live') {?>
						<option value="live" selected="selected"><?php echo $text_live; ?></option>
						<?php } else { ?>
						<option value="live"><?php echo $text_live; ?></option>
						<?php } ?>
						<?php if ($nimbbl_mode == 'test') { ?>
						<option value="test" selected="selected"><?php echo $text_test; ?></option>
						<?php } else { ?>
						<option value="test"><?php echo $text_test; ?></option>
						<?php } ?>                
					</select>
				</div>
          </div>
		  <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_testendpoint"><span data-toggle="tooltip" title="<?php echo $help_testendpoint; ?>"><?php echo $entry_testendpoint; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_testendpoint" value="<?php echo $nimbbl_testendpoint; ?>" placeholder="<?php echo $entry_testendpoint; ?>" id="nimbbl_testendpoint" class="form-control" />
              <?php if ($error_testendpoint) { ?> 
              <div class="text-danger"><?php echo $error_testendpoint; ?></div>
              <?php } ?>
            </div>
          </div>
          <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_testpublickey"><span data-toggle="tooltip" title="<?php echo $help_testpublickey; ?>"><?php echo $entry_testpublickey; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_testpublickey" value="<?php echo $nimbbl_testpublickey; ?>" placeholder="<?php echo $entry_testpublickey; ?>" id="nimbbl_testpublickey" class="form-control" />
              <?php if ($error_testpublickey) { ?> 
              <div class="text-danger"><?php echo $error_testpublickey; ?></div>
              <?php } ?>
            </div>
          </div>
          <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_testprivatekey"><span data-toggle="tooltip" title="<?php echo $help_testprivatekey; ?>"><?php echo $entry_testprivatekey; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_testprivatekey" value="<?php echo $nimbbl_testprivatekey; ?>" placeholder="<?php echo $entry_testprivatekey; ?>" id="nimbbl_testprivatekey" class="form-control" />
              <?php if ($error_testprivatekey) { ?>
              <div class="text-danger"><?php echo $error_testprivatekey; ?></div>
              <?php } ?>
            </div>
          </div>
		  <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_liveendpoint"><span data-toggle="tooltip" title="<?php echo $help_liveendpoint; ?>"><?php echo $entry_liveendpoint; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_liveendpoint" value="<?php echo $nimbbl_liveendpoint; ?>" placeholder="<?php echo $entry_liveendpoint; ?>" id="nimbbl_liveendpoint" class="form-control" />
              <?php if ($error_liveendpoint) { ?> 
              <div class="text-danger"><?php echo $error_liveendpoint; ?></div>
              <?php } ?>
            </div>
          </div>
          <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_livepublickey"><span data-toggle="tooltip" title="<?php echo $help_livepublickey; ?>"><?php echo $entry_livepublickey; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_livepublickey" value="<?php echo $nimbbl_livepublickey ?>" placeholder="<?php echo $entry_livepublickey; ?>" id="nimbbl_livepublickey" class="form-control" />
              <?php if($error_livepublickey) { ?> 
              <div class="text-danger"><?php echo $error_livepublickey; ?></div>
              <?php } ?>
            </div>
          </div>
          <div class="form-group required">
            <label class="col-sm-2 control-label" for="nimbbl_liveprivatekey"><span data-toggle="tooltip" title="<?php echo $help_liveprivatekey; ?>"><?php echo $entry_liveprivatekey; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_liveprivatekey" value="<?php echo $nimbbl_liveprivatekey; ?>" placeholder="<?php echo $entry_liveprivatekey; ?>" id="nimbbl_liveprivatekey" class="form-control" />
              <?php if($error_liveprivatekey) { ?>
              <div class="text-danger"><?php echo $error_liveprivatekey; ?></div>
              <?php } ?>
            </div>
          </div>
		  <div class="form-group">
            <label class="col-sm-2 control-label" for="nimbbl_geo_zone_id"><span data-toggle="tooltip" title="<?php echo $help_geozone; ?>"><?php echo $entry_geo_zone; ?></span></label>
            <div class="col-sm-10">
              <select name="nimbbl_geo_zone_id" id="nimbbl_geo_zone_id" class="form-control">
                <option value="0"><?php echo $text_all_zones; ?></option>
                <?php foreach($geo_zones as $geo_zone) { ?>
                <?php if ($geo_zone['geo_zone_id'] == $nimbbl_geo_zone_id) { ?>
                <option value="<?php echo $geo_zone['geo_zone_id']; ?>" selected="selected"><?php echo $geo_zone['name']; ?></option>
                <?php } else { ?>
                <option value="<?php echo $geo_zone['geo_zone_id']; ?>"><?php echo $geo_zone['name']; ?></option>
                <?php }} ?>                
              </select>
            </div>
          </div>          
          <div class="form-group">
            <label class="col-sm-2 control-label" for="nimbbl_total"><span data-toggle="tooltip" title="<?php echo $help_total; ?>"><?php echo $entry_total; ?></span></label>
            <div class="col-sm-10">
              <input type="text" name="nimbbl_total" value="<?php echo $nimbbl_total; ?>" placeholder="<?php echo $entry_total; ?>" id="nimbbl_total" class="form-control" />
            </div>
          </div>
          
          <!--order_status-->
          
          <div class="form-group">
             <label class="col-sm-2 control-label" for="nimbbl_order_status_id"><span data-toggle="tooltip" title="<?php echo $help_orderstatus; ?>"><?php echo $entry_order_status; ?></span></label>
               <div class="col-sm-10">
                 <select name="nimbbl_order_status_id" id="nimbbl_order_status_id" class="form-control">
                    <?php foreach ($order_statuses as $order_status) { ?>
                    <?php if ($order_status['order_status_id'] == $nimbbl_order_status_id) { ?>
                      <option value="<?php echo $order_status['order_status_id']; ?>" selected="selected"><?php echo $order_status['name']; ?></option>
					<?php } else  { ?>
                      <option value="<?php echo $order_status['order_status_id']; ?>"><?php echo $order_status['name']; ?></option>
                    <?php }} ?>                    
                 </select>
               </div> 
          </div>
          
          <!--order_status-->          
          
          <!--order_fail_status-->
          
          <div class="form-group">
             <label class="col-sm-2 control-label" for="nimbbl_order_fail_status_id"><span data-toggle="tooltip" title="<?php echo $help_orderfailstatus; ?>"><?php echo $entry_order_fail_status; ?></span></label>
               <div class="col-sm-10">
                 <select name="nimbbl_order_fail_status_id" id="nimbbl_order_fail_status_id" class="form-control">
                    <?php foreach($order_statuses as $order_status) { ?>
                    <?php if ($order_status['order_status_id'] == $nimbbl_order_fail_status_id) { ?>
                      <option value="<?php echo $order_status['order_status_id']; ?>" selected="selected"><?php echo $order_status['name']; ?></option>
                    <?php } else { ?>
                      <option value="<?php echo $order_status['order_status_id']; ?>"><?php echo $order_status['name']; ?></option>
                    <?php }} ?>
                 </select>
               </div> 
          </div>
          
          <!--order_fail_status-->    
          
          <div class="form-group">
              <label class="col-sm-2 control-label" for="nimbbl_status"><span data-toggle="tooltip" title="<?php echo $help_pluginstatus; ?>"><?php echo $entry_status; ?></span></label>
                 <div class="col-sm-10">
                   <select name="nimbbl_status" id="nimbbl_status" class="form-control">
                      <?php if ($nimbbl_status) { ?>
                         <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                         <option value="0"><?php echo $text_disabled; ?></option>
                      <?php } else { ?>
                         <option value="1"><?php echo $text_enabled; ?></option>
                         <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                      <?php } ?>
                   </select>
                   <?php if ($error_status) { ?>
                	<div class="text-danger"><?php echo $error_status; ?></div>
            	 	<?php } ?>
                 </div>                  
          </div>
          
          <div class="form-group">
               <label class="col-sm-2 control-label" for="nimbbl_sort_order"><span data-toggle="tooltip" title="<?php echo $help_sortorder; ?>"><?php echo $entry_sort_order; ?></span></label>
               	 <div class="col-sm-10">
                      <input type="text" name="nimbbl_sort_order" value="<?php echo $nimbbl_sort_order; ?>"  id="nimbbl_sort_order" class="form-control"size="1" />
                 </div>
          </div> 

      </div>
     </div>
     </div>
    <!--// Nimbbl End //-->
<hr />
</form>
<?php echo $footer; ?>