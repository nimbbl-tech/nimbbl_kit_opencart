<?php if ($error) {
    echo $error; 
 } else { 
    echo $data;
 } ?>
	