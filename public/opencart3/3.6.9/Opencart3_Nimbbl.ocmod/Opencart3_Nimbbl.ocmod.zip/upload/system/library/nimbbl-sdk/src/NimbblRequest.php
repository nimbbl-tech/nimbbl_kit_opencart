<?php

namespace Nimbbl\Api;

use Requests;
use Requests_Auth;
use Exception;
use Requests_Hooks;


// Available since PHP 5.5.19 and 5.6.3
// https://git.io/fAMVS | https://secure.php.net/manual/en/curl.constants.php
if (defined('CURL_SSLVERSION_TLSv1_1') === false) {
    define('CURL_SSLVERSION_TLSv1_1', 5);
}


// class NimbblAuth implements Requests_Auth
// {
//     protected $token;
//     protected $accessSecret;

//     public function __construct($token)
//     {
//         $this->token = $token;
//     }

//     public function register(Requests_Hooks $hooks)
//     {
//         $hooks->register('requests.before_request', array($this, 'before_request'));
//     }

//     public function before_request(&$url, &$headers, &$data, &$type, &$options)
//     {
//         $headers['Authorization'] = 'Bearer ' . $this->token;
//     }
// }

/**
 * Request class to communicate to the request libarary
 */
class NimbblRequest
{
    /**
     * Headers to be sent with every http request to the API
     * @var array
     */
    protected static $headers = array(
        'Nimbbl-API'  =>  1
    );

    /**
     * Enhanced logging function that ensures logs are always printed
     */
    private function logMessage($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] [NimbblRequest] {$message}" . PHP_EOL;
        
        // Write to error log (will appear in nginx error.log)
        error_log($logMessage);
        
        // Also write to a custom log file for better tracking
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        // Force output to stdout if possible (for CLI debugging)
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }

    /**
     * Fires a request to the API
     * @param  string   $method HTTP Verb
     * @param  string   $url    Relative URL for the request
     * @param  array $data Data to be passed along the request
     * @return array Response data in array format. Not meant
     * to be used directly
     */
    public function request($method, $url, $data = array())
    {
        $this->logMessage("request START - method: {$method}, url: {$url}");
        
        try {
            $endpoint = $url;
            $url = NimbblApi::getFullUrl($url);
            $hooks = new Requests_Hooks();
            $hooks->register('curl.before_send', array($this, 'setCurlSslOpts'));
            $nimbblToken = self::generateToken();
            $options = [
                'hook' => $hooks,
                'timeout' => 60,
            ];
            $headers = $this->getRequestHeaders();
            $headers['Authorization'] = 'Bearer ' . $nimbblToken['token'];
            $requestBody = (strtolower($method) === 'post') ? json_encode($data) : $data;
            
            $this->logMessage("request PREPARED - endpoint: {$endpoint}, fullUrl: {$url}");
            $this->logMessage("request HEADERS: " . print_r($headers, true), 'DEBUG');
            $this->logMessage("request BODY: " . $requestBody, 'DEBUG');
            
            $response = Requests::request($url, $headers, $requestBody, $method, $options);
            
            $this->logMessage("request RESPONSE - status: {$response->status_code}");
            $this->logMessage("response HEADERS: " . print_r($response->headers, true), 'DEBUG');
            $this->logMessage("response BODY: " . $response->body, 'DEBUG');
            
            $result = json_decode($response->body, true);
            $this->logMessage("request DECODED RESPONSE: " . print_r($result, true), 'DEBUG');
            $this->logMessage("request END - SUCCESS");
            
            return $result;
        } catch (Exception $e) {
            $this->logMessage("request ERROR: " . $e->getMessage() . PHP_EOL . $e->getTraceAsString(), 'ERROR');
            throw $e;
        }
    }

    public function universalRequest($method, $url, $data = array())
    {
        $this->logMessage("universalRequest START - method: {$method}, url: {$url}");
        
        try {
            $endpoint = $url;
            $url = NimbblApi::getFullUrl($url);
            $hooks = new Requests_Hooks();
            $hooks->register('curl.before_send', array($this, 'setCurlSslOpts'));
            $nimbblToken = self::generateToken();
            $options = [
                'hook' => $hooks,
                'timeout' => 60,
            ];
            $headers = $this->getRequestHeaders();
            $headers['Authorization'] = 'Bearer ' . $nimbblToken['token'];
            $requestBody = (strtolower($method) === 'post') ? json_encode($data) : $data;
            
            $this->logMessage("universalRequest PREPARED - endpoint: {$endpoint}, fullUrl: {$url}");
            $this->logMessage("universalRequest HEADERS: " . print_r($headers, true), 'DEBUG');
            $this->logMessage("universalRequest BODY: " . $requestBody, 'DEBUG');
            
            $response = Requests::request($url, $headers, $requestBody, $method, $options);
            
            $this->logMessage("universalRequest RESPONSE - status: {$response->status_code}");
            $this->logMessage("universalRequest response HEADERS: " . print_r($response->headers, true), 'DEBUG');
            $this->logMessage("universalRequest response BODY: " . $response->body, 'DEBUG');
            
            $result = json_decode($response->body, true);
            $this->logMessage("universalRequest DECODED RESPONSE: " . print_r($result, true), 'DEBUG');
            $this->logMessage("universalRequest END - SUCCESS");
            
            return $result;
        } catch (Exception $e) {
            $this->logMessage("universalRequest ERROR: " . $e->getMessage() . PHP_EOL . $e->getTraceAsString(), 'ERROR');
            throw $e;
        }
    }

    public function setCurlSslOpts($curl)
    {
        $this->logMessage("setCurlSslOpts START");
        curl_setopt($curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_1);
        $this->logMessage("setCurlSslOpts END");
    }

    /**
     * Adds an additional header to all API requests
     * @param string $key   Header key
     * @param string $value Header value
     * @return null
     */
    public static function addHeader($key, $value)
    {
        $logMessage = "[NimbblRequest] addHeader START - key: {$key}, value: {$value}" . PHP_EOL;
        error_log($logMessage);
        
        // Also write to custom log file
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        self::$headers[$key] = $value;
        
        $endMessage = "[NimbblRequest] addHeader END" . PHP_EOL;
        error_log($endMessage);
        file_put_contents($logFile, $endMessage, FILE_APPEND | LOCK_EX);
    }

    /**
     * Returns all headers attached so far
     * @return array headers
     */
    public static function getHeaders()
    {
        $logMessage = "[NimbblRequest] getHeaders START" . PHP_EOL;
        error_log($logMessage);
        
        // Also write to custom log file
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        $headers = self::$headers;
        
        $endMessage = "[NimbblRequest] getHeaders END - headers: " . print_r($headers, true) . PHP_EOL;
        error_log($endMessage);
        file_put_contents($logFile, $endMessage, FILE_APPEND | LOCK_EX);
        
        return $headers;
    }

    /**
     * Process the statusCode of the response and throw exception if necessary
     * @param Object $response The response object returned by Requests
     */
    protected function checkErrors($response)
    {
        $this->logMessage("checkErrors START - status: {$response->status_code}");
        
        $body = $response->body;
        $httpStatusCode = $response->status_code;

        try {
            $body = json_decode($response->body, true);
        } catch (Exception $e) {
            $this->logMessage("checkErrors ERROR: " . $e->getMessage(), 'ERROR');
            $this->throwServerError($body, $httpStatusCode);
        }

        if (($httpStatusCode < 200) or ($httpStatusCode >= 300)) {
            $this->processError($body, $httpStatusCode, $response);
        }
        
        $this->logMessage("checkErrors END");
    }

    protected function processError($body, $httpStatusCode, $response)
    {
        $this->logMessage("processError START - status: {$httpStatusCode}");
        
        // TODO: FIXME based on the error structure coming from NimbblAPI.
        $code = $body['error']['code'];
        $description = $body['error']['description'];
        
        $this->logMessage("processError ERROR: {$description} ({$code})", 'ERROR');
        throw new NimbblError($description, $code, $httpStatusCode);
    }

    protected function throwServerError($body, $httpStatusCode)
    {
        $this->logMessage("throwServerError START - status: {$httpStatusCode}");
        
        $description = "The server did not send back a well-formed response. Server response: $body";
        $this->logMessage("throwServerError ERROR: {$description}", 'ERROR');
        throw new NimbblError($description, NimbblErrorCode::SERVER_ERROR, $httpStatusCode);
    }

    public function getRequestHeaders()
    {
        $this->logMessage("getRequestHeaders START");
        
        $uaHeader = array(
            'User-Agent' => $this->constructUa()
        );

        $headers = array_merge(self::$headers, $uaHeader);

        $this->logMessage("getRequestHeaders END - headers: " . print_r($headers, true), 'DEBUG');
        return $headers;
    }

    protected function constructUa()
    {
        $this->logMessage("constructUa START");
        
        $ua = 'Nimbbl/v1 PHPSDK/' . NimbblApi::VERSION . ' PHP/' . phpversion();
        $ua .= ' ' . $this->getAppDetailsUa();

        $this->logMessage("constructUa END - ua: {$ua}");
        return $ua;
    }

    protected function getAppDetailsUa()
    {
        $this->logMessage("getAppDetailsUa START");
        
        $appsDetails = NimbblApi::$appsDetails;
        $appsDetailsUa = '';

        foreach ($appsDetails as $app) {
            if ((isset($app['title'])) and (is_string($app['title']))) {
                $appUa = $app['title'];

                if ((isset($app['version'])) and (is_scalar($app['version']))) {
                    $appUa .= '/' . $app['version'];
                }

                $appsDetailsUa .= $appUa . ' ';
            }
        }

        $this->logMessage("getAppDetailsUa END - ua: {$appsDetailsUa}");
        return $appsDetailsUa;
    }

    public function generateToken()
    {
        $this->logMessage("generateToken START");
        
        try {
            $nimbblSegment = new NimbblSegment();
            $tokenResponse = Requests::post(NimbblApi::getTokenEndpoint(), ['Content-Type' => 'application/json'], json_encode(['access_key' => NimbblApi::getKey(), 'access_secret' => NimbblApi::getSecret()]));
            $tokenResponseBody = json_decode($tokenResponse->body, true);
            
            $this->logMessage("generateToken RESPONSE - status: {$tokenResponse->status_code}");
            $this->logMessage("generateToken RESPONSE BODY: " . print_r($tokenResponseBody, true), 'DEBUG');
            
            if (key_exists('error', $tokenResponseBody)) {
                $this->logMessage("generateToken ERROR: " . $tokenResponseBody['error']['nimbbl_error_code'], 'ERROR');
            }
            
            $this->logMessage("generateToken END - SUCCESS");
            return $tokenResponseBody;
        } catch (Exception $e) {
            $this->logMessage("generateToken ERROR: " . $e->getMessage(), 'ERROR');
            throw $e;
        }
    }

    // /**
    //  * Verifies error is in proper format. If not then
    //  * throws ServerErrorException
    //  *
    //  * @param  array $body
    //  * @param  int $httpStatusCode
    //  * @return void
    //  */
    // protected function verifyErrorFormat($body, $httpStatusCode)
    // {
    //     if (is_array($body) === false)
    //     {
    //         $this->throwServerError($body, $httpStatusCode);
    //     }

    //     if ((isset($body['error']) === false) or
    //         (isset($body['error']['code']) === false))
    //     {
    //         $this->throwServerError($body, $httpStatusCode);
    //     }

    //     $code = $body['error']['code'];

    //     if (Errors\ErrorCode::exists($code) === false)
    //     {
    //         $this->throwServerError($body, $httpStatusCode);
    //     }
    // }
}
