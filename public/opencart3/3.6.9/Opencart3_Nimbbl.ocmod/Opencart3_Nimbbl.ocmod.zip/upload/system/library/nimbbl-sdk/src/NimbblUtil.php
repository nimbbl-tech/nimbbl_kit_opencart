<?php

declare(strict_types=1);

namespace Nimbbl\Api;

class NimbblUtil
{
    const SHA256 = 'sha256';

    /**
     * Enhanced logging function that ensures logs are always printed
     */
    private function logMessage($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] [NimbblUtil] {$message}" . PHP_EOL;
        
        // Write to error log (will appear in nginx error.log)
        error_log($logMessage);
        
        // Also write to a custom log file for better tracking
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        // Force output to stdout if possible (for CLI debugging)
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }

    public function verifyPaymentSignature(array $attributes, float $orderAmount): bool
    {
        $this->logMessage("verifyPaymentSignature START - orderAmount: {$orderAmount}");

        try {
            $actualSignature = $attributes['transaction']['signature'] ?? null;
            $nimbbl_transaction_id = $attributes['nimbbl_transaction_id'] ?? '';
            $orderId = $attributes['order']['invoice_id'] ?? '';

            $this->logMessage("Input validation - actualSignature: " . ($actualSignature ? 'present' : 'missing') . 
                             ", nimbbl_transaction_id: {$nimbbl_transaction_id}, orderId: {$orderId}");

            if (!$actualSignature) {
                $this->logMessage("ERROR: actualSignature is missing or empty", 'ERROR');
                return false;
            }

            $signature_string = "";

            if (!empty($attributes['transaction']['signature_version']) &&
                $attributes['transaction']['signature_version'] === 'v3') {

                $this->logMessage("Using signature version v3");
                $amount = $this->formatAmount($attributes['transaction']['transaction_amount']);
                $signature_string = implode('|', [
                    $orderId,
                    $nimbbl_transaction_id,
                    $amount,
                    $attributes['transaction']['transaction_currency'] ?? '',
                    $attributes['transaction']['status'] ?? '',
                    $attributes['transaction']['transaction_type'] ?? ''
                ]);
            } else {
                $this->logMessage("Using legacy signature version");
                $amount = sprintf("%.2f", $orderAmount);
                $signature_string = implode('|', [
                    $orderId,
                    $nimbbl_transaction_id,
                    $amount,
                    $attributes['transaction']['transaction_currency'] ?? ''
                ]);
            }

            $this->logMessage("Generated signature_string: {$signature_string}");

            $secret = NimbblApi::getSecret();
            if (!$secret) {
                $this->logMessage("ERROR: secret is empty or null", 'ERROR');
                return false;
            }

            $maskedSecret = substr($secret, 0, 4) . str_repeat('*', max(0, strlen($secret) - 8)) . substr($secret, -4);
            $this->logMessage("Secret validation passed - maskedSecret: {$maskedSecret}");

            $this->logMessage("Calling verifySignature()");
            $result = $this->verifySignature($signature_string, $actualSignature, $secret, $attributes);

            $this->logMessage("verifyPaymentSignature DEBUG: " .
                "signature_string=[{$signature_string}] | " .
                "orderAmount=[{$orderAmount}] | " .
                "actualSignature=[{$actualSignature}] | " .
                "maskedSecret=[{$maskedSecret}] | " .
                "verified=[" . var_export($result, true) . "] | " .
                "attributes=" . str_replace(["\n", "\r"], '', print_r($attributes, true))
            );

            $this->logMessage("verifyPaymentSignature END - Result: " . ($result ? 'SUCCESS' : 'FAILED'));
            return $result;
        } catch (\Exception $e) {
            $this->logMessage("verifyPaymentSignature ERROR: " . $e->getMessage() . PHP_EOL . $e->getTraceAsString(), 'ERROR');
            throw $e;
        }
    }

    public function verifySignature(string $payload, string $actualSignature, string $secret, array $attributes): bool
    {
        $this->logMessage("verifySignature START");

        $expectedSignature = hash_hmac(self::SHA256, $payload, $secret);

        $verified = function_exists('hash_equals')
            ? hash_equals($expectedSignature, $actualSignature)
            : $this->hashEquals($expectedSignature, $actualSignature);

        $maskedSecret = substr($secret, 0, 4) . str_repeat('*', max(0, strlen($secret) - 8)) . substr($secret, -4);

        $this->logMessage("verifySignature DEBUG: " .
            "payload=[" . $payload . "] | " .
            "actualSignature=[" . $actualSignature . "] | " .
            "expectedSignature=[" . $expectedSignature . "] | " .
            "actualSignatureHex=[" . bin2hex($actualSignature) . "] | " .
            "expectedSignatureHex=[" . bin2hex($expectedSignature) . "] | " .
            "maskedSecret=[" . $maskedSecret . "] | " .
            "verified=[" . var_export($verified, true) . "] | " .
            "attributes=" . str_replace(["\n", "\r"], '', print_r($attributes, true))
        );

        $this->logMessage("verifySignature END - Result: " . ($verified ? 'SUCCESS' : 'FAILED'));
        return $verified;
    }

    public function formatAmount($amount): string
    {
        $this->logMessage("formatAmount START - Input: {$amount}");
        
        $inp = str_replace(',', '', (string)$amount);
        $parts = explode('.', $inp);
        $whole = $parts[0];
        $decimal = isset($parts[1]) ? $parts[1] : '00';

        if (strlen($decimal) === 1) {
            $decimal .= '0';
        } elseif (strlen($decimal) > 2) {
            $decimal = substr($decimal, 0, 2);
        }

        $totalAmount = $whole . '.' . $decimal;
        $this->logMessage("formatAmount END - Result: {$totalAmount}");
        return $totalAmount;
    }

    private function hashEquals(string $expectedSignature, string $actualSignature): bool
    {
        $this->logMessage("hashEquals START");
        
        if (strlen($expectedSignature) !== strlen($actualSignature)) {
            $this->logMessage("hashEquals FAILED - Length mismatch: expected=" . strlen($expectedSignature) . ", actual=" . strlen($actualSignature));
            return false;
        }

        $res = $expectedSignature ^ $actualSignature;
        $result = 0;
        for ($i = strlen($res) - 1; $i >= 0; $i--) {
            $result |= ord($res[$i]);
        }
        
        $this->logMessage("hashEquals END - Result: " . ($result === 0 ? 'SUCCESS' : 'FAILED'));
        return $result === 0;
    }
}
