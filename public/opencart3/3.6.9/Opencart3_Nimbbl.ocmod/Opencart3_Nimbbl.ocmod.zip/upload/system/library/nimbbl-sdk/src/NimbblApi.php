<?php

namespace Nimbbl\Api;

class NimbblApi
{
    protected static $baseUrl = 'https://api.nimbbl.tech/api/';

    protected static $apiVersion = 'v3';

    protected static $key;

    protected static $secret;

    protected static $merchantId;

    /*
     * App info is to store the Plugin/integration
     * information
     */
    // public static $appsDetails = array();

    const VERSION = '3.0.0-vdc';

    /*
     * App info is to store the Plugin/integration
     * information
     */
    public static $appsDetails = [];

    /**
     * Enhanced logging function that ensures logs are always printed
     */
    private static function logMessage($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] [NimbblApi] {$message}" . PHP_EOL;
        
        // Write to error log (will appear in nginx error.log)
        error_log($logMessage);
        
        // Also write to a custom log file for better tracking
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        // Force output to stdout if possible (for CLI debugging)
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }

    /**
     * @param string $key
     * @param string $secret
     */
    public function __construct($key, $secret, $url=null, $apiVersion = null)
    {
        self::logMessage("__construct START - key: " . substr($key, 0, 4) . "****, url: " . ($url ?? 'default'), 'DEBUG');
        
        self::$key = $key;
        self::$secret = $secret;
        if($url != null)
            self::$baseUrl = $url;
        if($apiVersion != null)
            self::$apiVersion = $apiVersion;
            
        self::logMessage("__construct END - baseUrl: " . self::$baseUrl . ", apiVersion: " . self::$apiVersion);
    }

    /*
     *  Set Headers
     */
    public function setHeader($header, $value)
    {
        self::logMessage("setHeader START - header: {$header}, value: {$value}");
        \Nimbbl\Api\NimbblRequest::addHeader($header, $value);
        self::logMessage("setHeader END");
    }

    // public function setAppDetails($title, $version = null)
    // {
    //     $app = array(
    //         'title' => $title,
    //         'version' => $version
    //     );

    //     array_push(self::$appsDetails, $app);
    // }

    // public function getAppsDetails()
    // {
    //     return self::$appsDetails;
    // }

    // public function setBaseUrl($baseUrl)
    // {
    //     self::$baseUrl = $baseUrl;
    // }

    /**
     * @param string $name
     * @return mixed
     */
    public function __get($name)
    {
        self::logMessage("__get START - name: {$name}");
        $className = __NAMESPACE__ . '\\Nimbbl' . ucwords($name);

        $entity = new $className();

        self::logMessage("__get END - created entity: {$className}");
        return $entity;
    }

    public static function getBaseUrl()
    {
        self::logMessage("getBaseUrl START");
        $url = self::$baseUrl;
        // Set default if not set or empty
        if (empty($url)) {
            $url = 'https://api.nimbbl.tech/api/';
            self::$baseUrl = $url;
            self::logMessage("getBaseUrl - Set default URL: {$url}");
        }
        self::logMessage("getBaseUrl END - returning: {$url}");
        return $url;
    }

    public static function getAPIVersion() {
        self::logMessage("getAPIVersion START");
        $ver = self::$apiVersion;
        self::logMessage("getAPIVersion END - returning: {$ver}");
        return $ver;
    }

    public static function getKey()
    {
        self::logMessage("getKey START");
        $key = self::$key;
        $maskedKey = $key ? substr($key, 0, 4) . str_repeat('*', max(0, strlen($key) - 8)) . substr($key, -4) : 'null';
        self::logMessage("getKey END - returning masked key: {$maskedKey}");
        return $key;
    }

    public static function getSecret()
    {
        self::logMessage("getSecret START");
        $secret = self::$secret;
        $maskedSecret = $secret ? substr($secret, 0, 4) . str_repeat('*', max(0, strlen($secret) - 8)) . substr($secret, -4) : 'null';
        self::logMessage("getSecret END - returning masked secret: {$maskedSecret}");
        return $secret;
    }

    public static function getTokenEndpoint()
    {
        self::logMessage("getTokenEndpoint START");
        $baseUrl = rtrim(self::getBaseUrl(), '/');
        $apiVersion = ltrim(self::getAPIVersion(), '/');
        $endpoint = $baseUrl . '/' . $apiVersion . '/generate-token';
        self::logMessage("getTokenEndpoint END - returning: {$endpoint}");
        return $endpoint;
    }

    public static function getFullUrl($relativeUrl)
    {
        self::logMessage("getFullUrl START - relativeUrl: {$relativeUrl}");
        $baseUrl = rtrim(self::getBaseUrl(), '/');
        $relativeUrl = ltrim($relativeUrl, '/');
        $url = $baseUrl . '/' . $relativeUrl;
        self::logMessage("getFullUrl END - returning: {$url}");
        return $url;
    }

    public static function setMerchantId($merchantId){
        self::logMessage("setMerchantId START - merchantId: {$merchantId}");
        self::$merchantId = $merchantId;
        self::logMessage("setMerchantId END");
        return true;
    }

    public static function getMerchantId(){
        self::logMessage("getMerchantId START");
        $id = self::$merchantId;
        self::logMessage("getMerchantId END - returning: " . ($id ?? 'null'));
        return $id;
    }
}
