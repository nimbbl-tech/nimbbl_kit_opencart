<?php

namespace Nimbbl\Api;

use Exception;
use JsonSerializable;


class NimbblOrder extends NimbblEntity implements JsonSerializable
{
    public $token; // Add this line to declare the token property

    /**
     * Enhanced logging function that ensures logs are always printed
     */
    private function logMessage($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] [NimbblOrder] {$message}" . PHP_EOL;
        
        // Write to error log (will appear in nginx error.log)
        error_log($logMessage);
        
        // Also write to a custom log file for better tracking
        $logFile = dirname(__FILE__) . '/../../../logs/nimbbl_debug.log';
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        // Force output to stdout if possible (for CLI debugging)
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }

    public function entityClass()
    {
        return 'Nimbbl\\Api\\NimbblOrder';
    }

    /**
     *  @param $id Customer id description
     */

    public function retrieveMany($options = array())
    {
        $this->logMessage("retrieveMany START - options: " . print_r($options, true), 'DEBUG');
        
        $f = base64_encode($this->buildHttpQuery($options));
        $nimbblRequest = new NimbblRequest();
        $manyEntities = $nimbblRequest->request('GET', 'orders/many?f=' . $f . '&pt=no');
        $users = array();
        if (is_array($manyEntities) && isset($manyEntities['items']) && is_array($manyEntities['items'])) {
            foreach ($manyEntities['items'] as $idx => $oneEntity) {
                $users[] = $this->fillOne($oneEntity);
            }
        }
        
        $this->logMessage("retrieveMany END - found " . count($users) . " entities");
        return [
            'items' => $users,
            'meta' => $manyEntities['_meta'] ?? []
        ];
    }

    public function create($attributes = array(), $apiVersion = 'v3')
    {
        $this->logMessage("create START - apiVersion: {$apiVersion}");
        $this->logMessage("create ATTRIBUTES: " . print_r($attributes, true), 'DEBUG');
        
        try {
            $endpoint = $apiVersion.'/create-order';
            $fullUrl = \Nimbbl\Api\NimbblApi::getFullUrl($endpoint);
            $nimbblRequest = new NimbblRequest();
            $headers = $nimbblRequest->getRequestHeaders();
            $tokenArr = $nimbblRequest->generateToken();
            $headers['Authorization'] = 'Bearer ' . $tokenArr['token'];
            $requestBody = json_encode($attributes);
            
            $this->logMessage("create PREPARED - endpoint: {$endpoint}, fullUrl: {$fullUrl}");
            $this->logMessage("create HEADERS: " . print_r($headers, true), 'DEBUG');
            $this->logMessage("create BODY: " . $requestBody, 'DEBUG');
            
            // Only make one API request and log the response
            $hooks = new \Requests_Hooks();
            $hooks->register('curl.before_send', array($nimbblRequest, 'setCurlSslOpts'));
            $options = [
                'hook' => $hooks,
                'timeout' => 60,
            ];
            $rawResponse = \Requests::request($fullUrl, $headers, $requestBody, 'POST', $options);
            
            $this->logMessage("create RESPONSE - status: {$rawResponse->status_code}");
            $this->logMessage("create response HEADERS: " . print_r($rawResponse->headers, true), 'DEBUG');
            $this->logMessage("create response BODY: " . $rawResponse->body, 'DEBUG');
            
            // Log the raw JSON response for debugging
            $this->logMessage("create RAW JSON RESPONSE: " . $rawResponse->body);
            
            $createdEntity = json_decode($rawResponse->body, true);
            $newCreatedEntity = new NimbblOrder();
            
            if (is_array($createdEntity) && isset($createdEntity['token'])) {
                $this->logMessage("create SUCCESS - token found in response");
                // Set all top-level fields as direct properties for easy access
                foreach ($createdEntity as $key => $value) {
                    $newCreatedEntity->$key = $value;
                }
                $newCreatedEntity->attributes = $createdEntity;
            } elseif (is_array($createdEntity) && isset($createdEntity['order']) && is_array($createdEntity['order'])) {
                $this->logMessage("create SUCCESS - order found in response");
                $attributes = $createdEntity['order'];
                $newCreatedEntity->attributes = $attributes;
                if (isset($attributes['token'])) {
                    $newCreatedEntity->token = $attributes['token'];
                }
            } elseif (is_array($createdEntity) && isset($createdEntity['error'])) {
                $this->logMessage("create ERROR: " . print_r($createdEntity['error'], true), 'ERROR');
                $newCreatedEntity->error = $createdEntity['error'];
            } else {
                $this->logMessage("create ERROR: Unexpected API response: " . print_r($createdEntity, true), 'ERROR');
            }
            
            $this->logMessage("create END - result: " . print_r($newCreatedEntity, true), 'DEBUG');
            return $newCreatedEntity;
        } catch (\Exception $e) {
            $this->logMessage("create ERROR: " . $e->getMessage() . PHP_EOL . $e->getTraceAsString(), 'ERROR');
            throw $e;
        }
    }

    public function retrieveOne($id)
    {
        $this->logMessage("retrieveOne START - id: {$id}");
        
        $nimbblRequest = new NimbblRequest();
        $oneEntity = $nimbblRequest->request('GET', 'v2/get-order/' . $id);
        $loadedEntity = $this->fillOne($oneEntity);
        $this->attributes = $loadedEntity->attributes;
        $this->error = $loadedEntity->error;
        
        $this->logMessage("retrieveOne END - success");
        return $this;
    }

    public function edit($attributes = null)
    {
        $this->logMessage("edit START - attributes: " . print_r($attributes, true), 'DEBUG');
        $this->logMessage("edit ERROR: Unsupported operation", 'ERROR');
        throw new Exception("Unsupported operation.");
    }

    public function getOrderByInvoiceId($id, $apiVersion = 'v3'){
        $this->logMessage("getOrderByInvoiceId START - id: {$id}, apiVersion: {$apiVersion}");
        
        $nimbblrequest = new NimbblRequest();
        $response = $nimbblrequest->request('GET', $apiVersion.'/order?invoice_id='.$id);
        
        if (is_array($response) && key_exists('error', $response)){
            $errorCode = $response['error']['nimbbl_error_code'] ?? 'unknown';
            $this->logMessage("getOrderByInvoiceId ERROR: Get Order By Invoice Id failed due to {$errorCode}", 'ERROR');
            return (array) $response['error'];
        }
        
        $this->logMessage("getOrderByInvoiceId END - success");
        return $response;
    }

    public function getOrderByOrderId($id, $apiVersion = 'v3'){
        $this->logMessage("getOrderByOrderId START - id: {$id}, apiVersion: {$apiVersion}");
        
        $nimbblrequest = new NimbblRequest();
        $response = $nimbblrequest->request('GET', $apiVersion.'/order?order_id='.$id);
        
        if (is_array($response) && key_exists('error', $response)){
            $errorCode = $response['error']['nimbbl_error_code'] ?? 'unknown';
            $this->logMessage("getOrderByOrderId ERROR: Get Order By Order Id failed due to {$errorCode}", 'ERROR');
            return (array) $response['error'];
        }
        
        $this->logMessage("getOrderByOrderId END - success");
        return $response;
    }
}